#include<stdio.h>
#include<stdlib.h>
#include <ctype.h>
#include <math.h>
#define tam  100
#define tam1 1000
#define tam2 10000
#define tam3 100000
long int comp = 0; double troca = 0;
void bubble( int v[], int qtd )
{
  int i;
  int j;
  int aux;
  int k = qtd - 1 ;

  for(i = 0; i < qtd; i++)
  {
     for(j = 0; j < k; j++)
     {
     	comp++;
        if(v[j] > v[j+1])
        {
            aux = v[j];
        v[j] = v[j+1];
        v[j+1]=aux;
        troca++;
        }
     }
     k--;
  }
}

void quick_sort(int vet[], int ini, int fim)
{
    int pivo = ini, i, aux,j;


    for (i=ini+1; i<=fim; i++)
    {
        j = i;
        if(vet[j] < vet[pivo])
        {
            comp++;
            aux = vet[j];
            while (j > pivo)
            {
                vet[j] = vet[j-1];
                j--;
            }
            troca++;
            vet[j] = aux;
            troca++;
            pivo++;
        }
    }
    if(pivo-1 >= ini)
    {
        comp++;
        quick_sort(vet,ini,pivo-1);
    }
    if(pivo+1 <= fim)
    {
        comp++;
        quick_sort(vet,pivo+1,fim);
    }
}

void heapsort(int a[], int n) {
   int i = n / 2, pai, filho, t;
   for (;;) {
      if (i > 0) {
          i--;
          t = a[i];
      } else {
          n--;
          if (n == 0) return;
          t = a[n];
          a[n] = a[0];
      }
      pai = i;
      filho = i * 2 + 1;
      while (filho < n) {
          if ((filho + 1 < n)  &&  (a[filho + 1] > a[filho])){
          	filho++;
          	comp++;
		  }
          if (a[filho] > t) {
             comp++;
			 a[pai] = a[filho];
			 troca++;
			 pai = filho;
             filho = pai * 2 + 1;
          } else {
             break;
          }
      }
      a[pai] = t;
      troca++;
   }
}

int main()
{
 int vet[tam],vet1[tam1],vet2[tam2],vet3[tam3],a,i,escolha=-1;
    int limpa=0;
    while (escolha != 0 )
    {
        printf("\n#################################\n");
        printf("| 1 - Gerar arquivo de 100\t|\n");
        printf("| 2 - Gerar arquivo de 1.000\t|\n");
        printf("| 3 - Gerar arquivo de 10.000\t|\n");
        printf("| 4 - Gerar arquivo de 100.000\t|\n");
        printf("| 5 - Ordenar arquivo de 100\t|\n");
        printf("| 6 - Ordenar arquivo de 1.000\t|\n");
        printf("| 7 - Ordenar arquivo de 10.000\t|\n");
        printf("| 8 - Ordenar arquivo de 100.000|\n");
        printf("| 0 - EXIT\t\t\t|\n");
        printf("#################################\n");
        printf("\nEscolha: ");
        scanf("%d",&escolha);
        FILE *arq;
        switch (escolha)
        {
        case 0:
            printf("obrigado volte sempre\n");
            return 0;
            break;
        case 1:
            arq = fopen("arquivoCem.txt","w");
            if(arq==NULL)
            {
                printf("bugou arquivo!");
                break;
            }
            printf("gerou um arquivo de %d numeros\n",tam);
            for (i=0; i<tam; i++)
            {
                a = rand()%tam;
                fprintf(arq,"%d\n",a);

            }
            fclose(arq);
            printf("\n");

            break;
        case 2:
            arq = fopen("arquivoMil.txt","w");
            if(arq==NULL)
            {
                printf("bugou arquivo!");
                break;
            }
            printf("gerou um arquivo de %d numeros\n",tam1);
            for (i=0; i<tam1; i++)
            {
                a = rand()%tam1;
                fprintf(arq,"%d\n",a);

            }
            fclose(arq);
            printf("\n");
            break;
        case 3:
            arq = fopen("arquivoDezMil.txt","w");
            if(arq==NULL)
            {
                printf("bugou arquivo!");
                break;
            }
            printf("gerou um arquivo de %d numeros\n",tam2);
            for (i=0; i<tam2; i++)
            {
                a = rand()%tam2;
                fprintf(arq,"%d\n",a);

            }
            fclose(arq);
            printf("\n");
            break;

        case 4:
            arq = fopen("arquivoCemMil.txt","w");
            if(arq==NULL)
            {
                printf("bugou arquivo!");
                break;
            }
            printf("gerou um arquivo de %d numeros\n",tam3);
            for (i=0; i<tam3; i++)
            {
                a = rand()%tam3;
                fprintf(arq,"%d\n",a);

            }
            fclose(arq);
            printf("\n");
            break;
        default:
            printf("Numero n�o cadastrado\n");
        case 5:
            arq = fopen("arquivoCem.txt","r");
            char info[10];
            for (i=0; i<tam;)
            {
                fgets(info,sizeof(info),arq);
                vet[i] = atoi(info);
                i++;
            }
           int veta[tam];
           for (i=0;i<tam;i++){
            veta[i] = vet[i];
           }
           bubble(veta,tam-1);
            arq = fopen("arquivoCemOrdenadosBubble.txt","w");
            if(arq==NULL)
            {
                printf("bugou arquivo!");
            }
            for(i=0; i<tam; i++)
            {
                a = veta[i];
                fprintf(arq,"%d\n",a);
            }
            printf("arquivo Ordenado\n");
            printf("Algoritmo  \t|  Compara��es\t| Trocas\n");
            printf("Bubble Sort \t| %li       \t| %.0lf",comp,troca);
            printf("\n");
            troca = comp =0;
            fclose(arq);

            for (i=0;i<tam;i++){
                veta[i] = vet[i];
           }
           quick_sort(veta,0,tam-1);
            arq = fopen("arquivoCemOrdenadosQuick.txt","w");
            if(arq==NULL)
            {
                printf("bugou arquivo!");
            }
            for(i=0; i<tam; i++)
            {
                a = veta[i];
                fprintf(arq,"%d\n",a);
            }
            printf("Quick Sort \t| %li       \t| %.0lf",comp,troca);
            printf("\n");
            troca = comp =0;
            fclose(arq);

            for (i=0;i<tam;i++){
            veta[i] = vet[i];
           }
           heapsort(veta,tam-1);
            arq = fopen("arquivoCemOrdenadosHeap.txt","w");
            if(arq==NULL)
            {
                printf("bugou arquivo!");
            }
            for(i=0; i<tam; i++)
            {
                a = veta[i];
                fprintf(arq,"%d\n",a);
            }
            printf("Heap Sort \t| %li       \t| %.0lf",comp,troca);
            printf("\n");
            troca = comp =0;
            fclose(arq);

            break;
        case 6:
            arq = fopen("arquivoMil.txt","r");
            char info1[10];
            for (i=0; i<tam1;)
            {
                fgets(info1,sizeof(info1),arq);
                vet1[i] = atoi(info1);
                i++;
            }
            int vetb[tam1];
            for (i=0;i<tam1;i++){
            vetb[i] = vet[i];
            }
            bubble(vetb,tam1-1);
            arq = fopen("arquivoMilOrdenadosBubble.txt","w");
            if(arq==NULL)
            {
                printf("bugou arquivo!");
            }
            for(i=0; i<tam1; i++)
            {
                a = vetb[i];
                fprintf(arq,"%d\n",a);
            }
            printf("arquivo de Mil Ordenado\n");
            printf("Algoritmo  \t|  Compara��es\t| Trocas\n");
            printf("Bubble Sort \t| %li       \t| %.0lf",comp,troca);
            printf("\n");
            comp = 0, troca = 0;
            fclose(arq);

            for (i=0;i<tam1;i++){
            vetb[i] = vet[i];
            }
             quick_sort(vetb,0,tam1-1);
            arq = fopen("arquivoMilOrdenadosQuick.txt","w");
            if(arq==NULL)
            {
                printf("bugou arquivo!");
            }
            for(i=0; i<tam1; i++)
            {
                a = vetb[i];
                fprintf(arq,"%d\n",a);
            }
            printf("Quick Sort \t| %li       \t| %.0lf",comp,troca);
            printf("\n");
            troca = comp =0;
            fclose(arq);

            for (i=0;i<tam1;i++){
            vetb[i] = vet[i];
            }
            heapsort(vetb,tam1-1);
            arq = fopen("arquivoMilOrdenadosHeap.txt","w");
            if(arq==NULL)
            {
                printf("bugou arquivo!");
            }
            for(i=0; i<tam1; i++)
            {
                a = vetb[i];
                fprintf(arq,"%d\n",a);
            }
            printf("Heap Sort \t| %li       \t| %.0lf",comp,troca);
            printf("\n");
            troca = comp =0;
            fclose(arq);


            break;
        case 7:
            arq = fopen("arquivoDezMil.txt","r");
            char info2[10];
            for (i=0; i<tam2;)
            {
                fgets(info2,sizeof(info2),arq);
                vet2[i] = atoi(info2);
                i++;
            }
            int vetc[tam2];
            for (i=0;i<tam2;i++){
            vetc[i] = vet2[i];
            }
            bubble(vetc,tam2-1);
            arq = fopen("arquivoDezMilOrdenadosBubble.txt","w");
            if(arq==NULL)
            {
                printf("bugou arquivo!");
            }
            for(i=0; i<tam2; i++)
            {
                a = vetc[i];
                fprintf(arq,"%d\n",a);
            }
            printf("arquivo de Dez Mil Ordenado\n");
            printf("Algoritmo  \t|  Compara��es\t| Trocas\n");
            printf("Bubble Sort \t| %li       \t| %.0lf",comp,troca);
            printf("\n");
            comp = 0, troca = 0;
            fclose(arq);

            for (i=0;i<tam2;i++){
            vetc[i] = vet2[i];
            }
             quick_sort(vetc,0,tam2-1);
            arq = fopen("arquivoDezMilOrdenadosQuick.txt","w");
            if(arq==NULL)
            {
                printf("bugou arquivo!");
            }
            for(i=0; i<tam2; i++)
            {
                a = vetc[i];
                fprintf(arq,"%d\n",a);
            }
            printf("Quick Sort \t| %li       \t| %.0lf",comp,troca);
            printf("\n");
            troca = comp =0;
            fclose(arq);

            for (i=0;i<tam2;i++){
            vetc[i] = vet2[i];
            }
            heapsort(vetc,tam2-1);
            arq = fopen("arquivoDezMilOrdenadosHeap.txt","w");
            if(arq==NULL)
            {
                printf("bugou arquivo!");
            }
            for(i=0; i<tam2; i++)
            {
                a = vetc[i];
                fprintf(arq,"%d\n",a);
            }
            printf("Heap Sort \t| %li       \t| %.0lf",comp,troca);
            printf("\n");
            troca = comp =0;
            fclose(arq);

            break;
        case 8:
            arq = fopen("arquivoCemMil.txt","r");
            char info3[13];
            for (i=0; i<tam3;)
            {
                fgets(info3,sizeof(info3),arq);
                vet3[i] = atoi(info3);
                i++;
            }
            int vetd[tam3];
            for (i=0;i<tam3;i++){
            vetd[i] = vet3[i];
            }
            bubble(vetd,tam3-1);
            arq = fopen("arquivoCemMilOrdenadosBubble.txt","w");
            if(arq==NULL)
            {
                printf("bugou arquivo!");
            }
            for(i=0; i<tam3; i++)
            {
                a = vetd[i];
                fprintf(arq,"%d\n",a);
            }
            printf("arquivo de Cem Mil Ordenado\n");
            printf("Algoritmo  \t|  Compara��es\t\t| Trocas\n");
            printf("Bubble Sort \t| %li \t\t| %.0lf",comp,troca);
            printf("\n");
            comp = 0, troca = 0;
            fclose(arq);

            for (i=0;i<tam3;i++){
            vetd[i] = vet3[i];
            }
             quick_sort(vetd,0,tam3-1);
            arq = fopen("arquivoCemMilOrdenadosQuick.txt","w");
            if(arq==NULL)
            {
                printf("bugou arquivo!");
            }
            for(i=0; i<tam3; i++)
            {
                a = vetd[i];
                fprintf(arq,"%d\n",a);
            }
            printf("Quick Sort \t| %li \t\t| %.0lf",comp,troca);
            printf("\n");
            troca = comp =0;
            fclose(arq);

            for (i=0;i<tam3;i++){
            vetd[i] = vet3[i];
            }
            heapsort(vetd,tam3-1);
            arq = fopen("arquivoCemMilOrdenadosHeap.txt","w");
            if(arq==NULL)
            {
                printf("bugou arquivo!");
            }
            for(i=0; i<tam3; i++)
            {
                a = vetd[i];
                fprintf(arq,"%d\n",a);
            }
            printf("Heap Sort \t| %li \t\t| %.0lf",comp,troca);
            printf("\n");
            troca = comp =0;
            fclose(arq);

            break;
        }
        limpa++;
    }
    return 0;
}
