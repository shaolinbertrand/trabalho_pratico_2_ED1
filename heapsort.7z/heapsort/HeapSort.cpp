#include<stdio.h>
#include<stdlib.h>
#include <ctype.h>
#include <math.h>
#define tam  100
#define tam1 1000
#define tam2 10000
#define tam3 100000
long int comp = 0; double troca = 0;
void heapsort(int a[], int n) {
   int i = n / 2, pai, filho, t;
   for (;;) {
      if (i > 0) {
          i--;
          t = a[i];
      } else {
          n--;
          if (n == 0) return;
          t = a[n];
          a[n] = a[0];
      }
      pai = i;
      filho = i * 2 + 1;
      while (filho < n) {
          if ((filho + 1 < n)  &&  (a[filho + 1] > a[filho])){
          	filho++;
          	comp++;
		  }
          if (a[filho] > t) {
             comp++;
			 a[pai] = a[filho];
			 troca++;
			 pai = filho;
             filho = pai * 2 + 1;
          } else {
             break;
          }
      }
      a[pai] = t;
      troca++;
   }
}
int main()
{
    int vet[tam],vet1[tam1],vet2[tam2],vet3[tam3],a,i,escolha=-1;
    int limpa=0;
    while (escolha != 0 )
    {
       /* if(limpa == 2){
            system("pause");
            system("cls");
            limpa=0;
        }*/

        printf("\n#################################\n");
        printf("| 1 - Gerar arquivo de 100\t|\n");
        printf("| 2 - Gerar arquivo de 1.000\t|\n");
        printf("| 3 - Gerar arquivo de 10.000\t|\n");
        printf("| 4 - Gerar arquivo de 100.000\t|\n");
        printf("| 5 - Ordenar arquivo de 100\t|\n");
        printf("| 6 - Ordenar arquivo de 1.000\t|\n");
        printf("| 7 - Ordenar arquivo de 10.000\t|\n");
        printf("| 8 - Ordenar arquivo de 100.000|\n");
        printf("| 0 - EXIT\t\t\t|\n");
        printf("#################################\n");
        printf("\nEscolha: ");
        scanf("%d",&escolha);
        FILE *arq;
        switch (escolha)
        {
        case 0:
            printf("obrigado volte sempre\n");
            return 0;
            break;
        case 1:
            arq = fopen("arquivoCem.txt","w");
            if(arq==NULL)
            {
                printf("bugou arquivo!");
                break;
            }
            printf("gerou um arquivo de %d numeros\n",tam);
            for (i=0; i<tam; i++)
            {
                a = rand()%tam;
                fprintf(arq,"%d\n",a);

            }
            fclose(arq);
            printf("\n");

            break;
        case 2:
            arq = fopen("arquivoMil.txt","w");
            if(arq==NULL)
            {
                printf("bugou arquivo!");
                break;
            }
            printf("gerou um arquivo de %d numeros\n",tam1);
            for (i=0; i<tam1; i++)
            {
                a = rand()%tam1;
                fprintf(arq,"%d\n",a);

            }
            fclose(arq);
            printf("\n");
            break;
        case 3:
            arq = fopen("arquivoDezMil.txt","w");
            if(arq==NULL)
            {
                printf("bugou arquivo!");
                break;
            }
            printf("gerou um arquivo de %d numeros\n",tam2);
            for (i=0; i<tam2; i++)
            {
                a = rand()%tam2;
                fprintf(arq,"%d\n",a);

            }
            fclose(arq);
            printf("\n");
            break;

        case 4:
            arq = fopen("arquivoCemMil.txt","w");
            if(arq==NULL)
            {
                printf("bugou arquivo!");
                break;
            }
            printf("gerou um arquivo de %d numeros\n",tam3);
            for (i=0; i<tam3; i++)
            {
                a = rand()%tam3;
                fprintf(arq,"%d\n",a);

            }
            fclose(arq);
            printf("\n");
            break;
        default:
            printf("Numero n�o cadastrado\n");
        case 5:
            arq = fopen("arquivoCem.txt","r");
            char info[10];
            for (i=0; i<tam;)
            {
                fgets(info,sizeof(info),arq);
                vet[i] = atoi(info);
                i++;
            }
           heapsort (vet,tam);
            arq = fopen("arquivoCemOrdenados.txt","w");
            if(arq==NULL)
            {
                printf("bugou arquivo!");
            }
            for(i=0; i<tam; i++)
            {
                a = vet[i];
                fprintf(arq,"%d\n",a);
            }
            printf("arquivo Ordenado\n");
            printf("houve %li comparacoes e %.0lf trocas",comp,troca);
            printf("\n");
            comp = 0, troca = 0;
            fclose(arq);
            break;
        case 6:
            arq = fopen("arquivoMil.txt","r");
            char info1[10];
            for (i=0; i<tam1;)
            {
                fgets(info1,sizeof(info1),arq);
                vet1[i] = atoi(info1);
                i++;
            }
            heapsort (vet1,tam1);
            arq = fopen("arquivoMilOrdenados.txt","w");
            if(arq==NULL)
            {
                printf("bugou arquivo!");
            }
            for(i=0; i<tam1; i++)
            {
                a = vet1[i];
                fprintf(arq,"%d\n",a);
            }
            printf("arquivo Ordenado\n");
            printf("houve %li comparacoes e %.0lf trocas",comp,troca);
            printf("\n");
            comp = 0, troca = 0;
            fclose(arq);
            break;
        case 7:
            arq = fopen("arquivoDezMil.txt","r");
            char info2[10];
            for (i=0; i<tam2;)
            {
                fgets(info2,sizeof(info2),arq);
                vet2[i] = atoi(info2);
                i++;
            }
            heapsort (vet2,tam2);
            arq = fopen("arquivoDezMilOrdenados.txt","w");
            if(arq==NULL)
            {
                printf("bugou arquivo!");
            }
            for(i=0; i<tam2; i++)
            {
                a = vet2[i];
                fprintf(arq,"%d\n",a);
            }
            printf("arquivo Ordenado\n");
            printf("houve %li comparacoes e %.0lf trocas",comp,troca);
            printf("\n");
            comp = 0, troca = 0;
            fclose(arq);
            break;
        case 8:
            arq = fopen("arquivoCemMil.txt","r");
            char info3[13];
            for (i=0; i<tam3;)
            {
                fgets(info3,sizeof(info3),arq);
                vet3[i] = atoi(info3);
                i++;
            }
           heapsort (vet3,tam3);
            arq = fopen("arquivoCemMilOrdenados.txt","w");
            if(arq==NULL)
            {
                printf("bugou arquivo!");
            }
            for(i=0; i<tam3; i++)
            {
                a = vet3[i];
                fprintf(arq,"%d\n",a);
            }
            printf("arquivo Ordenado\n");
            printf("houve %li comparacoes e %.0lf trocas",comp,troca);
            printf("\n");
            comp = 0, troca = 0;
            fclose(arq);
            break;
        }
        limpa++;
    }
    return 0;
}
